package com.example.channel;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText mEmailView;
    private EditText mPasswordView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void Submit(View view){
        mEmailView = findViewById(R.id.username);
        mPasswordView = findViewById(R.id.password);
        String email = mEmailView.getText().toString();
        String password = mPasswordView.getText().toString();
        Toast.makeText(getBaseContext(),
                email + "and" + password,
                Toast.LENGTH_SHORT).show();

    }
}
